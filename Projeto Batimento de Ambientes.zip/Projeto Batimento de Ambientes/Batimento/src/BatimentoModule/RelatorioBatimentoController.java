/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BatimentoModule;

/**
 *
 * @author 80574691
 */
public class RelatorioBatimentoController {
    
    private String _status;
    private String _type;
    private String _groupObject;    
    private String _orderCol;
    private String _description;
    private String _parN0;
    private String _parN1;
    private String _parN2;
    private String _parN3;
    private String _objectName;
    private String _columnName;
    private String _valOrig;
    private String _valDest;
    private String _lastUpdOrig;
    private String _lastUpdDest;
    private String _ctrlLogComRepId;
    private String _lastUpdByDest;
    private String _id;    

    /**
     * @return the _status
     */
    public String getStatus() {
        return _status;
    }

    /**
     * @param _status the _status to set
     */
    public void setStatus(String _status) {
        this._status = _status;
    }

    /**
     * @return the _type
     */
    public String getType() {
        return _type;
    }

    /**
     * @param _type the _type to set
     */
    public void setType(String _type) {
        this._type = _type;
    }

    /**
     * @return the _groupObject
     */
    public String getGroupObject() {
        return _groupObject;
    }

    /**
     * @param _groupObject the _groupObject to set
     */
    public void setGroupObject(String _groupObject) {
        this._groupObject = _groupObject;
    }

    /**
     * @return the _orderCol
     */
    public String getOrderCol() {
        return _orderCol;
    }

    /**
     * @param _orderCol the _orderCol to set
     */
    public void setOrderCol(String _orderCol) {
        this._orderCol = _orderCol;
    }

    /**
     * @return the _description
     */
    public String getDescription() {
        return _description;
    }

    /**
     * @param _description the _description to set
     */
    public void setDescription(String _description) {
        this._description = _description;
    }

    /**
     * @return the _parN0
     */
    public String getParN0() {
        return _parN0;
    }

    /**
     * @param _parN0 the _parN0 to set
     */
    public void setParN0(String _parN0) {
        this._parN0 = _parN0;
    }

    /**
     * @return the _parN1
     */
    public String getParN1() {
        return _parN1;
    }

    /**
     * @param _parN1 the _parN1 to set
     */
    public void setParN1(String _parN1) {
        this._parN1 = _parN1;
    }

    /**
     * @return the _parN2
     */
    public String getParN2() {
        return _parN2;
    }

    /**
     * @param _parN2 the _parN2 to set
     */
    public void setParN2(String _parN2) {
        this._parN2 = _parN2;
    }

    /**
     * @return the _parN3
     */
    public String getParN3() {
        return _parN3;
    }

    /**
     * @param _parN3 the _parN3 to set
     */
    public void setParN3(String _parN3) {
        this._parN3 = _parN3;
    }

    /**
     * @return the _objectName
     */
    public String getObjectName() {
        return _objectName;
    }

    /**
     * @param _objectName the _objectName to set
     */
    public void setObjectName(String _objectName) {
        this._objectName = _objectName;
    }

    /**
     * @return the _columnName
     */
    public String getColumnName() {
        return _columnName;
    }

    /**
     * @param _columnName the _columnName to set
     */
    public void setColumnName(String _columnName) {
        this._columnName = _columnName;
    }

    /**
     * @return the _valOrig
     */
    public String getValOrig() {
        return _valOrig;
    }

    /**
     * @param _valOrig the _valOrig to set
     */
    public void setValOrig(String _valOrig) {
        this._valOrig = _valOrig;
    }

    /**
     * @return the _valDest
     */
    public String getValDest() {
        return _valDest;
    }

    /**
     * @param _valDest the _valDest to set
     */
    public void setValDest(String _valDest) {
        this._valDest = _valDest;
    }

    /**
     * @return the _lastUpdOrig
     */
    public String getLastUpdOrig() {
        return _lastUpdOrig;
    }

    /**
     * @param _lastUpdOrig the _lastUpdOrig to set
     */
    public void setLastUpdOrig(String _lastUpdOrig) {
        this._lastUpdOrig = _lastUpdOrig;
    }

    /**
     * @return the _lastUpdDest
     */
    public String getLastUpdDest() {
        return _lastUpdDest;
    }

    /**
     * @param _lastUpdDest the _lastUpdDest to set
     */
    public void setLastUpdDest(String _lastUpdDest) {
        this._lastUpdDest = _lastUpdDest;
    }

    /**
     * @return the _ctrlLogComRepId
     */
    public String getCtrlLogComRepId() {
        return _ctrlLogComRepId;
    }

    /**
     * @param _ctrlLogComRepId the _ctrlLogComRepId to set
     */
    public void setCtrlLogComRepId(String _ctrlLogComRepId) {
        this._ctrlLogComRepId = _ctrlLogComRepId;
    }

    /**
     * @return the _lastUpdByDest
     */
    public String getLastUpdByDest() {
        return _lastUpdByDest;
    }

    /**
     * @param _lastUpdByDest the _lastUpdByDest to set
     */
    public void setLastUpdByDest(String _lastUpdByDest) {
        this._lastUpdByDest = _lastUpdByDest;
    }

    /**
     * @return the _id
     */
    public String getId() {
        return _id;
    }

    /**
     * @param _id the _id to set
     */
    public void setId(String _id) {
        this._id = _id;
    }
    
}
