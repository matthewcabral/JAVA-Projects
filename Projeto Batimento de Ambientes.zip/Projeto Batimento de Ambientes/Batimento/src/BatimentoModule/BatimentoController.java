/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BatimentoModule;

import databaseModule.DataController;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataContentHandler;

/**
 *
 * @author 80603505
 */
public class BatimentoController {
    private String confName;
    private String firstAmb;
    private String secAmb;
    private String firstRep;
    private String secRep;
    private String dateSeachSpec;
    private int numThreads;
    
    BatimentoThread thread;

    // Empty Constructor
    public BatimentoController() {}

    public BatimentoController(String firstAmb, String secAmb, String firstRep, String secRep, String dateSeachSpec, int numThreads) {
        this.firstAmb = firstAmb;
        this.secAmb = secAmb;
        this.firstRep = firstRep;
        this.secRep = secRep;
        this.dateSeachSpec = dateSeachSpec;
        this.numThreads = numThreads;
    }

    // Getters and Setters
    public String getConfName() { return confName; }
    public void setConfName(String confName) { this.confName = confName; }
    
    public String getFirstAmb() { return firstAmb; }
    public void setFirstAmb(String firstAmb) { this.firstAmb = firstAmb; }

    public String getSecAmb() { return secAmb; }
    public void setSecAmb(String secAmb) { this.secAmb = secAmb; }

    public String getFirstRep() { return firstRep; }
    public void setFirstRep(String firstRep) { this.firstRep = firstRep; }

    public String getSecRep() { return secRep; }
    public void setSecRep(String secRep) { this.secRep = secRep; }

    public String getDateSeachSpec() { return dateSeachSpec; }
    public void setDateSeachSpec(String dateSeachSpec) { this.dateSeachSpec = dateSeachSpec; }

    public int getNumThreads() { return numThreads; }
    public void setNumThreads(int numThreads) { this.numThreads = numThreads; }
        
    // Function used to create Threads
    public void createThreads(){
        for(int i=1; i <= getNumThreads(); i++){
            thread = new BatimentoThread("Thread"+i, getFirstRep(), getSecRep(), getFirstAmb(), getSecAmb(), getDateSeachSpec(), String.valueOf(i), getConfName());
        }
        thread.waitThreadsEnd();
    }
}
