/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BatimentoModule;

import databaseModule.DataController;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

/**
 *
 * @author 80574691
 */
public class RelatorioBatimentoBS {
    
    DataController dataController;

    public RelatorioBatimentoBS() {
        dataController = new DataController() {};
    }

    public ArrayList<RelatorioBatimentoController> getRelatorioBatimento() {
        return dataController.getRelatorioBatimento();
    }

    public boolean geraRelatorioBatimentoCSV(String path) {

        ArrayList<RelatorioBatimentoController> result = this.getRelatorioBatimento();
        String header = "STATUS;TYPE;GROUP_OBJECT;ORDER_COL;DESCRIPTION;PAR_N0;PAR_N1;PAR_N2;PAR_N3;OBJECT_NAME;COLUMN_NAME;VAL_ORIG;VAL_DEST;LAST_UPD_ORIG;LAST_UPD_DEST;CTRL_LOG_COMP_REP_ID;LAST_UPD_BY_DEST;ID\n";
        boolean criado = false;

        if (!path.isEmpty()) {
            try {
                BufferedWriter buff = new BufferedWriter(new FileWriter(path));
                buff.append(header);

                for (int i = 0; i < result.size(); i++) {
                    buff.append(result.get(i).getStatus() + ";" + result.get(i).getType() + result.get(i).getGroupObject() + ";");
                    buff.append(result.get(i).getOrderCol() + ";" + result.get(i).getDescription() + result.get(i).getParN0() + ";");
                    buff.append(result.get(i).getParN1() + ";" + result.get(i).getParN2() + result.get(i).getParN3() + ";");
                    buff.append(result.get(i).getObjectName() + ";" + result.get(i).getColumnName() + result.get(i).getValOrig() + ";");
                    buff.append(result.get(i).getValDest() + ";" + result.get(i).getLastUpdOrig() + result.get(i).getLastUpdDest() + ";");
                    buff.append(result.get(i).getCtrlLogComRepId() + ";" + result.get(i).getLastUpdByDest() + "\n");

                }

                buff.close();
                criado = true;

            } catch (Exception e) {
                criado = false;
            }

        } else {
            criado = false;
        }

        return criado;
    }

}
