/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BatimentoModule;

import databaseModule.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 80603505
 */
public class BatimentoThread extends BatimentoController implements Runnable  {
    private String nome;
    private String RepOrigemName;
    private String RepDestinoName;
    private String DbLinkOrigem;
    private String DbLinkDestino;
    private String Data;
    private String FilaThreads;
    private String ConfName;

    DataController dataControl;
    Thread thread;
    
    public BatimentoThread(String nome, String RepOrigemName, String RepDestinoName, String DbLinkOrigem, String DbLinkDestino, String Data, String FilaThreads, String ConfName) {
        this.nome = nome;
        this.RepOrigemName = RepOrigemName;
        this.RepDestinoName = RepDestinoName;
        this.DbLinkOrigem = DbLinkOrigem;
        this.DbLinkDestino = DbLinkDestino;
        this.Data = Data;
        this.FilaThreads = FilaThreads;
        this.ConfName = ConfName;
        
        dataControl = new DataController(){};
        
        thread = new Thread(this);
        thread.start();
    }
    
    public void waitThreadsEnd(){
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(BatimentoThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Getters
    public String getNome() { return nome; }
    public String getRepOrigemName() { return RepOrigemName; }
    public String getRepDestinoName() { return RepDestinoName; }
    public String getDbLinkOrigem() {  return DbLinkOrigem; }
    public String getDbLinkDestino() { return DbLinkDestino; }
    public String getData() { return Data; }
    public String getFilaThreads() { return FilaThreads; }
    @Override
    public String getConfName() { return ConfName; }
        
    @Override
    public void run(){
        System.out.println(nome + " em execução");
        dataControl.runPLCompareAmb(getRepOrigemName(), getRepDestinoName(), getDbLinkOrigem(), getDbLinkDestino(), getData(), getFilaThreads(), getConfName());
        System.out.println(nome + " finalizada");
    }
}
