/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseModule;

import BatimentoModule.RelatorioBatimentoController;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author 80603505
 */
public abstract class DataController extends Controller{    
    SqlInstructions instructions;
    
    // Empty Constructor
    public DataController() {
        super.dbColumns = new ArrayList<>();
        super.dbConditionColumns = new ArrayList<>();
        instructions = new SqlInstructions();
    }  
    
    // Function to insert, select and delete data in Controller.dbColumns Array 
    public void addDbColumns(String columns){
        super.dbColumns.add(columns);
    }
    
    public void clearDbColumns(){
        super.dbColumns.clear(); // Clear ArrayList
        super.clearDbCondition(); // Clear variable
    }
    
    public String getDbColumns(){
        for(int i = 0; i <= super.dbColumns.size() - 1; i++){
            if(i < super.dbColumns.size() - 1){
                super.setColumnsCommand(super.dbColumns.get(i) + ",\n");
            } else {
                super.setColumnsCommand(super.dbColumns.get(i) + "\n");
            }
        }
        return super.getColumnsCommand();
    }
    // ===============================================================
    
    // Function to insert, select and delete data in dbConditionColumns Array
    public void addConditionColumns(String condition){
        super.dbConditionColumns.add(condition);
    }
    
    public String getCondition(){
        for(int i = 0; i <= super.dbConditionColumns.size() - 1; i++){
            if(i < super.dbConditionColumns.size() - 1){
                super.setDbCondition(super.dbConditionColumns.get(i) + "\nAND ");
            } else {
                super.setDbCondition(super.dbConditionColumns.get(i) + "\n");
            }
        }
        return super.getDbCondition();
    }
    
    public void clearConditionColumns(){
        super.dbConditionColumns.clear(); // Clear ArrayList
        super.clearDbCondition(); // Clear variable
    }
    // ===============================================================
    
    // Function to insert, select and delete data in dbConditionColumns Array
    public void addTable(String table){
        super.dbTable.add(table);
    }
    
    public String getTable(){
        for(int i = 0; i <= super.dbTable.size() - 1; i++){
            if(i < super.dbTable.size() - 1){
                super.setTable(super.dbTable.get(i) + ",\n");
            } else {
                super.setDbCondition(super.dbTable.get(i) + "\n");
            }
        }
        return super.getDbCondition();
    }
    
    public void clearTable(){
        super.dbTable.clear(); // Clear ArrayList
        super.clearTable(); // Clear variable
    }
    // ===============================================================
    
    @Override
    public void openConnection(String message){
        try {
            Class.forName(super.getDbLocation());
            //System.out.println("Oracle JDBC Driver Registered!");
        } catch (ClassNotFoundException e){
            JOptionPane.showMessageDialog(null, super.exc.getDbODBCEx() + "\n" + super.exc.getMsgReturn() + e, "Erro", JOptionPane.ERROR_MESSAGE);
        }
        try {
            conn = DriverManager.getConnection(getDbURL(), getDbUser(), getDbPassword());
            System.out.println(message + "\tConnected Successfuly!");
        } catch(SQLException e) {
            JOptionPane.showMessageDialog(null, super.exc.getDbConnectionEx()+ "\n" + super.exc.getMsgReturn() + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    @Override
    public void closeConnection(String message){
        try {
            Class.forName(super.getDbLocation());
            //System.out.println("Oracle JDBC Driver Registered!");
        } catch (ClassNotFoundException e){
            JOptionPane.showMessageDialog(null, super.exc.getDbODBCEx()+ "\n" + super.exc.getMsgReturn() + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        try {
            conn.close();
            System.out.println(message + "\tDisconnected Successfuly!");
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, super.exc.getDbDisconnectEx() + "\n" + super.exc.getMsgReturn() + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void selectFunction(String Query, int function){
        resultQuery = new ArrayList<>();
        try{
            openConnection("");
            super.statement = super.conn.createStatement();
            ResultSet readline = super.statement.executeQuery(Query);
            while(readline.next()){
                switch(function){
                    case 1: // Used on AboutViewScreen
                        resultQuery.add(readline.getString("HOST"));
                        break;
                    case 2: // Used to return Repository's and Projects
                        resultQuery.add(readline.getString("NAME"));
                        break;
                    case 3: // Used to get the maximum of threads used
                        resultQuery.add(readline.getString("FILA"));
                        break;
                    case 4: // Used to get the Value of Projects
                        resultQuery.add(readline.getString("VAL"));
                        break;
                    default:
                        break;
                }
                
            }
            readline.close();
            closeConnection("");
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro de leitura no Banco de Dados!\nMensagem: " + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void runPLCompareAmb(String RepOrigemName, String RepDestinoName, String DbLinkOrigem, String DbLinkDestino, String Data, String FilaThreads, String ConfName){
        try{
            openConnection("Thread " + String.valueOf(FilaThreads));
            super.statement = super.conn.createStatement();
            super.statement.execute(instructions.queryCompareRep(RepOrigemName, RepDestinoName, DbLinkOrigem, DbLinkDestino, Data, FilaThreads, ConfName));
            closeConnection("Thread " + String.valueOf(FilaThreads));
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao executar o processo no Banco de Dados!\nMensagem: " + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void runPLCompareAmbMaster(String RepOrigemName, String RepDestinoName, String DbLinkOrigem, String DbLinkDestino, String ConfName){
        try{
            openConnection("Tabela Master");
            super.statement = super.conn.createStatement();
            super.statement.execute(instructions.queryCompareRepMaster(RepOrigemName, RepDestinoName, DbLinkOrigem, DbLinkDestino, ConfName));
            closeConnection("Tabela Master");
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao executar o processo no Banco de Dados!\nMensagem: " + e,"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    public ArrayList<RelatorioBatimentoController> getRelatorioBatimento(){
        ArrayList<RelatorioBatimentoController> resultQuery = new ArrayList<>();
        String query = new SqlInstructions().getQueryRelatorioBatimento();//new SqlInstructions().getRelatorioBatimento();
        
        try{
            openConnection("");
            super.statement = super.conn.createStatement();
            ResultSet rs = super.statement.executeQuery(query);
            
            while(rs.next()){
                RelatorioBatimentoController rel = new RelatorioBatimentoController();
                
                rel.setStatus(rs.getString("STATUS"));
                rel.setType(rs.getString("TYPE"));
                rel.setGroupObject(rs.getString("GROUP_OBJECT"));
                rel.setOrderCol(rs.getString("ORDER_COL"));
                rel.setDescription(rs.getString("DESCRIPTION"));
                rel.setParN0(rs.getString("PAR_N0"));
                rel.setParN1(rs.getString("PAR_N1"));
                rel.setParN2(rs.getString("PAR_N2"));
                rel.setParN3(rs.getString("PAR_N3"));
                rel.setObjectName(rs.getString("OBJECT_NAME"));
                rel.setColumnName(rs.getString("COLUMN_NAME"));
                rel.setValOrig(rs.getString("VAL_ORIG"));
                rel.setValDest(rs.getString("VAL_DEST"));
                rel.setLastUpdOrig(rs.getString("LAST_UPD_ORIG"));
                rel.setLastUpdDest(rs.getString("LAST_UPD_DEST"));
                rel.setCtrlLogComRepId(rs.getString("CTRL_LOG_COMP_REP_ID"));
                rel.setLastUpdByDest(rs.getString("LAST_UPD_BY_DEST"));
                rel.setId(rs.getString("ID"));
                
                resultQuery.add(rel);        
            }
            rs.close();
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro de leitura no Banco de Dados!\nMensagem: " + e,"Erro",JOptionPane.ERROR_MESSAGE);
        } finally{
            closeConnection("");
        }
        return resultQuery;
    }
}
