/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseModule;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Matheus Cabral Rosa
 */
public abstract class Controller {
    // Database Variables
    public Connection conn = null;
    public Statement statement;
    private String dbDriver = "oracle.jdbc.OracleDriver"; // Driver used to connect on oracle database
    private String dbURL = "jdbc:oracle:thin:@localhost:1521:SIEBELDEV"; // Connection line used to connect to the database
    private String dbUser = "SADMIN"; // Array used to store database users
    private String dbPassword = "SADMIN"; // Array used to store database passwords
    private String dbOwner; // Array used to store database owners
    protected ArrayList<String> dbColumns; // Used to manipulate the columns of the table
    protected ArrayList<String> dbConditionColumns; // Used to manipulate the columns of the table
    protected ArrayList<String> dbTable;
    public ArrayList<String> resultQuery;
    protected String dbResultQuery[];
    private String table;
    private String columnsCommand; // Used to concatenate into a string the database commands
    private String dbCommand; // Used to run the final database command
    private String dbCondition; // Used to run the final database condition
    private String finalCommand;
    
    // Database exceptions list
    exceptionsController exc;
    
    // Empty Constructor
    public Controller() {
        exc = new exceptionsController();
        dbOwner = "";
        columnsCommand = "";
        dbCommand = "";
        dbCondition = "";
        finalCommand = "";
    }

    // Database Setters and Getters
    public String getDbLocation() { return dbDriver; }
    public void setDbLocation(String dbLocation) { this.dbDriver = dbLocation; }
    
    public String getDbURL() { return dbURL; }
    public void setDbURL(String ConnectionLine) { this.dbURL = ConnectionLine; }

    public String getDbCommand() { return dbCommand; }
    public void setDbCommand(String dbCommand) { this.dbCommand = dbCommand; }
    public void clearDbCommand(){this.dbCommand = ""; }

    public String getDbCondition() { return dbCondition; }
    public void setDbCondition(String dbCondition) { this.dbCondition += dbCondition; }
    public void clearDbCondition() { this.dbCondition = ""; }

    public String getDbDriver() { return dbDriver; }
    public void setDbDriver(String dbDriver) { this.dbDriver = dbDriver; }

    public String getDbUser() { return dbUser; }
    public void setDbUser(String dbUser) { this.dbUser = dbUser; }

    public String getDbPassword() { return dbPassword; }
    public void setDbPassword(String dbPassword) { this.dbPassword = dbPassword; }

    public String getDbOwner() { return dbOwner; }
    public void setDbOwner(String dbOwner) { this.dbOwner = dbOwner; }

    public String getColumnsCommand() { return columnsCommand; }
    public void setColumnsCommand(String columnsCommand) { this.columnsCommand = columnsCommand; }

    public String getFinalCommand() { return finalCommand; }
    public void setFinalCommand(String finalCommand) { this.finalCommand += finalCommand; }
    public void clearFinalCommand() { this.finalCommand = ""; }

    public ArrayList<String> getResultQuery() { return resultQuery; }
    public void setResultQuery(ArrayList<String> resultQuery) { this.resultQuery = resultQuery; }

    public String getTable() { return table; }
    public void clearTable() { this.table = ""; }
    public void setTable(String table) { this.table += table; }
       
    
    
    
    // Open Database Connection
    public abstract void openConnection(String message);
    
    // Close Database Connection
    public abstract void closeConnection(String message);
    
}
