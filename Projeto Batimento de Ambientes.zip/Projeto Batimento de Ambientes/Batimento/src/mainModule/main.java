/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainModule;

import static java.awt.Frame.MAXIMIZED_BOTH;

/**
 *
 * @author 80603505
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mainScreen mainScreen = new mainScreen();
        mainScreen.setExtendedState(MAXIMIZED_BOTH);
    }
    
}
