/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainModule;

import BatimentoModule.*;
import static java.awt.Frame.MAXIMIZED_BOTH;
import javax.swing.JPanel;

/**
 *
 * @author 80603505
 */
public class MainMenu {
    
    mainScreen main;
    BatimentoScreen batimentoSc;
    
    //public MainMenu() {}
    
    public MainMenu(mainScreen main){
        this.main = main;
    }
    
    public void openScreen(int function){
        switch(function){
            case 1:
                batimentoSc = new BatimentoScreen();
                batimentoSc.setExtendedState(MAXIMIZED_BOTH);
                //main.add(batimentoSc);
                break;
            default:
                break;
        }
    }
    
}
