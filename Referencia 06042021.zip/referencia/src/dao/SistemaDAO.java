package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Sistema;

public class SistemaDAO implements InterfaceSistemaDAO {
	
	Connection conexao;
	
	public SistemaDAO(Connection conexao) {
		this.conexao = conexao;
	}
	
	@Override
	public Boolean Inserir(Sistema _sistema) throws SQLException {

		String comando = "insert into sistema (nome) "
				+ "values (?)";

		PreparedStatement ps = this.conexao.prepareStatement(comando);
		ps.setString(1, _sistema.getNome());

		if(ps.execute()) {
			return true;
		}
		else {
			return false;
		}
		
	}

	@Override
	public List<Sistema> ListarTodos() throws SQLException {
		
		ResultSet rs = null;
		List<Sistema> listaSistemas = new ArrayList<Sistema>();
		
		try {
			
			String comando = "select * from sistema order by id ";
			
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
                Long id = rs.getLong(1);
                String nome = rs.getString(2);

                listaSistemas.add(new Sistema(id, nome));
            }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		return listaSistemas;
	}

	@Override
	public void Editar(Sistema _sistema) throws SQLException {

		String comando = "update sistema set nome = ? where id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setString(1, _sistema.getNome());
		
		ps.setLong(2, _sistema.getId());
		
		ps.execute();
		
	}	
	
	@Override
	public void Excluir(Sistema _sistema) throws SQLException {

		String comando = "delete from sistema where id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _sistema.getId());
		
		ps.execute();
		
	}

	@Override
	public Sistema PegarPeloID(Long _id) throws SQLException {

		String comando = "SELECT * FROM sistema WHERE id = ?";
	
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _id);

		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			Long id = rs.getLong(1);
            String nome = rs.getString(2);
            
            return new Sistema(id, nome);
		}
		else {
			return null;
		}

	}
}
