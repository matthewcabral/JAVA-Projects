package dao;

import java.sql.SQLException;
import java.util.List;

import modelo.Sistema;

public interface InterfaceSistemaDAO {
	
	public Boolean Inserir(Sistema _sistema) throws SQLException;

	public List<Sistema> ListarTodos() throws SQLException;
	
	public void Editar(Sistema _sistema) throws SQLException;
	
	public void Excluir(Sistema _sistema) throws SQLException;

	public Sistema PegarPeloID(Long _id) throws SQLException;

}
