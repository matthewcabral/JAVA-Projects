package dao;

import java.sql.SQLException;
import java.util.List;
import modelo.Pesquisador;
import modelo.Usuario;

public interface InterfacePesquisadorDAO {

	public void InserirNovo(Pesquisador _pesquisador) throws SQLException;
	
	public void InserirExiste(Pesquisador _pesquisador) throws SQLException;

	public void InserirEspecialidade(Long _pesquisadorId, Long _especialidadeId) throws SQLException;
	
	public void InserirEspecialidades(Pesquisador _pesquisador) throws SQLException;

	public void RemoverEspecialidade(Long _pesquisadorId, Long _especialidadeId) throws SQLException;	
	
	public void EditarEspecialidades(Long _idPesquisador, String _idsEspecialidades) throws SQLException;
	
	public List<Pesquisador> listarTodos() throws SQLException;
	
	public void Editar(Pesquisador _pesquisador) throws SQLException;
	
	public void EditarExiste(Pesquisador _pesquisador) throws SQLException;
	
	public void Aprovar(Pesquisador _pesquisador) throws SQLException;
	
	public void Excluir(Pesquisador _pesquisador) throws SQLException;
	
	public Long PegarProximoID() throws SQLException;
	
	public Pesquisador PegarPeloID(Long idPesquisador) throws SQLException;

	public List<Usuario> listarUsuariosParaPesquisador();

	List<Pesquisador> listarTodosPorEspecialidade(Long _idEspecialidade) throws SQLException;
	
	List<Pesquisador> listarTodosSemEspecialidade(Long _idEspecialidade) throws SQLException;
	
	public List<Pesquisador> listarPesquisadoresPendentes() throws SQLException;
}
