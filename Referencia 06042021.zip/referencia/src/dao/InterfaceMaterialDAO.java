package dao;

import java.sql.SQLException;
import java.util.List;

import modelo.Material;

public interface InterfaceMaterialDAO {
	
	public Boolean Inserir(Material _material) throws SQLException;

	public List<Material> ListarTodos() throws SQLException;
	
	public void Editar(Material _material) throws SQLException;
	
	public void Excluir(Material _material) throws SQLException;

	public Material PegarPeloID(int _id) throws SQLException;
	
	public List<Material> ListarPorSistema(Long idSistema) throws SQLException;

}
