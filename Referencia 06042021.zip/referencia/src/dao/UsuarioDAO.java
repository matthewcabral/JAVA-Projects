package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.TipoUsuario;
import modelo.Usuario;
import modelo.Pesquisador;

public class UsuarioDAO implements InterfaceUsuarioDAO {
		
	Connection conexao;
	
	public UsuarioDAO(Connection _conexao) {
		this.conexao = _conexao;
	}

	@Override
	public Long Inserir(Usuario _usuario) throws SQLException {

			String comando = "insert into usuario (nome, email, senha, tel, dtCadastro, tipoUsuario, status, dtStatus) "
					+ "values (?, ?, ?, ?, sysdate(), ?, ?, sysdate())";
					
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			//ps.setLong(1, _usuario.getId());
			ps.setString(1, _usuario.getNome().trim());
			ps.setString(2, _usuario.getEmail().trim());
			ps.setString(3, _usuario.getSenha().trim());
			ps.setString(4, _usuario.getTel().trim());
			ps.setString(5, _usuario.getTipoUsuario());
			ps.setString(6, _usuario.getStatus());
			
			ps.execute();	
			
			return PegarPeloEmail(_usuario.getEmail()).getId();
	}

	@Override
	public List<Usuario> listarTodos() {
		
		ResultSet rs = null;
		List<Usuario> listaUsuarios = new ArrayList<Usuario>();
		
		try {
			
			String comando = "select * from usuario order by id";
			
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
                Long id = rs.getLong(1);
                String nome = rs.getString(2);
                String email = rs.getString(3);
                String senha = rs.getString(4);
                String tel = rs.getString(5);
                Date dtCadastro = rs.getDate(6);
                String tipoUsuario = rs.getString(7);
                String status = rs.getString(8);
                Date dtStatus = rs.getDate(9);

                listaUsuarios.add(new Usuario(id, nome, senha, senha, tel, email, dtCadastro, tipoUsuario, status, dtStatus));
            }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		return listaUsuarios;
	}

	@Override
	public void Editar(Usuario _usuario) throws SQLException {
		
		String comando = "update usuario set nome = ?, email = ?, senha = ?, tel = ?, tipoUsuario = ?, status = ? where id = ?";
				
		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setString(1, _usuario.getNome());
		ps.setString(2, _usuario.getEmail());
		ps.setString(3, _usuario.getSenha());
		ps.setString(4, _usuario.getTel());
		ps.setString(5, _usuario.getTipoUsuario());
		ps.setString(6, _usuario.getStatus());
		
		ps.setLong(7, _usuario.getId());
		
		ps.execute();	
	}
	
	@Override
	public Long PegarProximoID()throws SQLException {
		
		Long id = new Long(0);
		
		String comando = "SELECT Auto_increment FROM information_schema.tables WHERE table_name='usuario'";
	
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			id = rs.getLong(1);
		}
		
		return id;
	}
	
	@Override
	public Usuario VerificarUsuario(String _email, String _senha) throws SQLException {

		String comando = "SELECT * FROM usuario WHERE email = ? AND senha = ?";
	
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setString(1, _email);
		ps.setString(2, _senha);
		
		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			Long id = rs.getLong(1);
            String nome = rs.getString(2);
            String email = rs.getString(3);
            String senha = rs.getString(4);
            String tel = rs.getString(5);
            Date dtCadastro = rs.getDate(6);
            String tipoUsuario = rs.getString(7);
            String status = rs.getString(8);
            Date dtStatus = rs.getDate(9);
            
            return new Usuario(id, nome, senha, senha, tel, email, dtCadastro, tipoUsuario, status, dtStatus);
		}
		else {
			return null;
		}

	}

	@Override
	public void Excluir(Usuario _usuario) throws SQLException {

		String comando = "delete from usuario where id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _usuario.getId());
		
		ps.execute();
		
	}
	
	@Override
	public Usuario PegarPeloID(Long _id) throws SQLException {
		
		String comando = "SELECT * FROM usuario WHERE id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _id);

		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			Long id = rs.getLong(1);
            String nome = rs.getString(2);
            String email = rs.getString(3);
            String senha = rs.getString(4);
            String tel = rs.getString(5);
            Date dtCadastro = rs.getDate(6);
            String tipoUsuario = rs.getString(7);
            String status = rs.getString(8);
            Date dtStatus = rs.getDate(9);
            
            return new Usuario(id, nome, senha, senha, tel, email, dtCadastro, tipoUsuario, status, dtStatus);
		}
		else {
			return null;
		}
	}
	
	@Override
	public Usuario PegarPeloEmail(String _email) throws SQLException {
		
		String comando = "SELECT * FROM usuario WHERE email = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setString(1, _email);

		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			Long id = rs.getLong(1);
            String nome = rs.getString(2);
            String email = rs.getString(3);
            String senha = rs.getString(4);
            String tel = rs.getString(5);
            Date dtCadastro = rs.getDate(6);
            String tipoUsuario = rs.getString(7);
            String status = rs.getString(8);
            Date dtStatus = rs.getDate(9);
            
            return new Usuario(id, nome, senha, senha, tel, email, dtCadastro, tipoUsuario, status, dtStatus);
		}
		else {
			return null;
		}
	}
	
	
}
