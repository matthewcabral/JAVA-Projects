package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Material;
import modelo.Sistema;

public class MaterialDAO implements InterfaceMaterialDAO {
	
	Connection conexao;
	
	public MaterialDAO(Connection conexao) {
		this.conexao = conexao;
	}
	
	@Override
	public Boolean Inserir(Material _sistema) throws SQLException {

		String comando = "insert into material (nome, sistemaId) "
				+ "values (?, ?)";

		PreparedStatement ps = this.conexao.prepareStatement(comando);
		ps.setString(1, _sistema.getNome());
		ps.setLong(2, _sistema.getSistema().getId());

		if(ps.execute()) {
			return true;
		}
		else {
			return false;
		}
		
	}

	@Override
	public List<Material> ListarTodos() throws SQLException {
		
		ResultSet rs = null;
		List<Material> listaSistemas = new ArrayList<Material>();
		
		try {
			
			String comando = "select * from material order by id ";
			
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
                Long id = rs.getLong(1);
                String nome = rs.getString(2);
                Long idSistema = rs.getLong(3);
                
                SistemaDAO daoSistema = new SistemaDAO(conexao);
                Sistema sistema = daoSistema.PegarPeloID(idSistema);

                listaSistemas.add(new Material(id, nome, sistema));
            }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		return listaSistemas;
	}

	@Override
	public void Editar(Material _sistema) throws SQLException {

		String comando = "update material set nome = ? where id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setString(1, _sistema.getNome());
		
		ps.setLong(2, _sistema.getId());
		
		ps.execute();
		
	}	
	
	@Override
	public void Excluir(Material _sistema) throws SQLException {

		String comando = "delete from material where id = ?";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _sistema.getId());
		
		ps.execute();
		
	}

	@Override
	public Material PegarPeloID(int _id) throws SQLException {

		String comando = "SELECT * FROM material WHERE id = ?";
	
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setInt(1, _id);

		ResultSet rs = ps.executeQuery();
		
		if (rs.next()) {
			Long id = rs.getLong(1);
            String nome = rs.getString(2);
            Long idSistema = rs.getLong(3);
            
            SistemaDAO daoSistema = new SistemaDAO(conexao);
            Sistema sistema = daoSistema.PegarPeloID(idSistema);
            
            return new Material(id, nome, sistema);
		}
		else {
			return null;
		}

	}
	
	@Override
	public List<Material> ListarPorSistema(Long idSistema) throws SQLException{
		
		ResultSet rs = null;
		List<Material> listaMateriais = new ArrayList<Material>();
		
		try {

            SistemaDAO daoSistema = new SistemaDAO(conexao);
            Sistema sistema = daoSistema.PegarPeloID(idSistema);
			
			String comando = "select * from material where sistemaId = ? order by id ";
			
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			
			ps.setLong(1, idSistema);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
                Long id = rs.getLong(1);
                String nome = rs.getString(2);
                
                listaMateriais.add(new Material(id, nome, sistema));
            }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		return listaMateriais;
	}
	
}
