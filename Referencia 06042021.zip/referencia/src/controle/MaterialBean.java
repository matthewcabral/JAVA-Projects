package controle;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;

import javax.faces.context.FacesContext;

import dao.MaterialDAO;
import dao.SistemaDAO;
import modelo.Material;
import modelo.Sistema;
import util.FabricaConexao;
import util.JSFUtil;

@ManagedBean
public class MaterialBean {

	private Material material;
	private Sistema sistema;
	private List<Material> materiais;

	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public List<Material> getMateriais() {
		return materiais;
	}

	public void setMateriais(List<Material> materiais) {
		this.materiais = materiais;
	}
	
	public Sistema getSistema() {
		return sistema;
	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}

	public void CadastrarMaterial() {
		try {
			
			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			MaterialDAO dao = new MaterialDAO(conexao);
			dao.Inserir(this.material);
			this.materiais = dao.ListarPorSistema(this.sistema.getId()); // Atualizar tela

			fabrica.fecharConexao();

			this.material = new Material();
			this.material.setSistema(this.sistema);

			JSFUtil.adicionarMensagemSucesso("Material criado com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void PrepararEditarMaterial(Material material) {
		try {

			this.material = material;

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}

	}

	public void EditarMaterial() {
		try {

			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			MaterialDAO dao = new MaterialDAO(conexao);
			dao.Editar(this.material);

			this.materiais = dao.ListarPorSistema(this.sistema.getId()); // Atualizar tela

			fabrica.fecharConexao();

			this.material = new Material();
			this.material.setSistema(this.sistema);

			JSFUtil.adicionarMensagemSucesso("Material editado com sucesso!");
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void CancelarEditarMaterial() {
		try {

			this.material = new Material();
			this.material.setSistema(this.sistema);

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void PrepararExcluirMaterial(Material material) {
		try {
			
			Map<String, Object> sessionMapObj = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			sessionMapObj.put("excluirMaterial", material);

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void ExcluirMaterial(Material material) {
		try {

			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			MaterialDAO dao = new MaterialDAO(conexao);
			dao.Excluir(material);

			this.materiais = dao.ListarTodos();

			fabrica.fecharConexao();

			JSFUtil.adicionarMensagemSucesso("Material exclu�do com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	@PostConstruct
	public void init() {
		try {

			Map<String, String> params =FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			String sistemaIdString = params.get("sistemaId");
			long sistemaId = Long.parseLong(sistemaIdString);
			
			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			MaterialDAO dao = new MaterialDAO(conexao);
			this.materiais = dao.ListarPorSistema(sistemaId);
			
            SistemaDAO daoSistema = new SistemaDAO(conexao);
            this.sistema = daoSistema.PegarPeloID(sistemaId);

			fabrica.fecharConexao();
			
			this.material = new Material();
			this.material.setSistema(this.sistema);

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}
}
