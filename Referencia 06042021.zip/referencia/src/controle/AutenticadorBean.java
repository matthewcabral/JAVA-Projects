package controle;

import java.sql.Connection;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import dao.UsuarioDAO;
import modelo.Usuario;
import util.BeanBase;
import util.FabricaConexao;
import util.JSFUtil;
import util.SessaoUtil;

@ManagedBean
public class AutenticadorBean extends BeanBase {

	private static final long serialVersionUID = 1L;
	
	private String email;
	private String senha;
	
	public AutenticadorBean() {
		super();
	}
	
	public AutenticadorBean(String email, String senha) {
		super();
		this.email = email;
		this.senha = senha;
	}
	
	public void initialize() throws Exception {
		Usuario user = (Usuario)SessaoUtil.getParametroSessao("USUARIOLogado");
		if(user!=null)
			FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	}
	
	public String autenticar() throws Exception {

		System.out.println("autenticando...");

		try {
			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			UsuarioDAO dao = new UsuarioDAO(conexao);

			Usuario user = dao.VerificarUsuario(this.email, this.senha);

			if (user != null) {
				
				if(user.getStatus().equals("Desativada")) {
					System.out.println("Conta desativada!!!");
					JSFUtil.adicionarMensagemErro("Sua conta ainda n�o est� ativa! Aguarde a ativa��o da conta por nossos administradores!");
					return null;
				} else if(user.getStatus().equals("Aguardando pagamento")) {
					System.out.println("AUTENTICADO!!!");
					SessaoUtil.setParametroSessao("USUARIOLogado", user);
					return "/cadastro/cad_pagamento.jsf?faces-redirect=true";
				} else {
					System.out.println("AUTENTICADO!!!");
					SessaoUtil.setParametroSessao("USUARIOLogado", user);
					return "/index.jsf?faces-redirect=true";
				}
			} else {
				
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, "E-mail ou senha inv�lido!", "Usu�rio ou senha inv�lido!"));
				return null;
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Ocorreu um erro na conexao!", "Tente novamente mais tarde."));
			return null;
		}

	}
	
	public void checkAlreadyLoggedin() {
		try {
			if(usuarioLogado()) {
				ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
				ec.redirect(ec.getRequestContextPath()+"/index.jsf");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private boolean usuarioLogado() throws Exception {
		Usuario user = (Usuario)SessaoUtil.getParametroSessao("USUARIOLogado");
		return user!=null;
	}

	public String registrarSaida() throws Exception {
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return "/default.xhtml?faces-redirect=true";
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
}
