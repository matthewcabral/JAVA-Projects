package controle;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;

import javax.faces.context.FacesContext;

import dao.SistemaDAO;
import modelo.Sistema;
import util.FabricaConexao;
import util.JSFUtil;

@ManagedBean
public class SistemaBean {

	private Sistema sistema;
	private List<Sistema> sistemas;

	public Sistema getSistema() {
		return sistema;
	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}

	public List<Sistema> getSistemas() {
		return sistemas;
	}

	public void setSistemas(List<Sistema> sistemas) {
		this.sistemas = sistemas;
	}

	public void CadastrarSistema() {
		try {
			
			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			SistemaDAO dao = new SistemaDAO(conexao);
			dao.Inserir(this.sistema);
			this.sistemas = dao.ListarTodos(); // Atualizar tela

			fabrica.fecharConexao();

			this.sistema = new Sistema();

			JSFUtil.adicionarMensagemSucesso("Sistema criado com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void PrepararEditarSistema(Sistema sistema) {
		try {

			this.sistema = sistema;

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}

	}

	public void EditarSistema() {
		try {

			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			SistemaDAO dao = new SistemaDAO(conexao);
			dao.Editar(this.sistema);

			this.sistemas = dao.ListarTodos(); // Atualizar tela

			fabrica.fecharConexao();

			this.sistema = new Sistema();

			JSFUtil.adicionarMensagemSucesso("Sistema editado com sucesso!");
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void CancelarEditarSistema() {
		try {

			this.sistema = new Sistema();

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void PrepararExcluirSistema(Sistema sistema) {
		try {
			
			Map<String, Object> sessionMapObj = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			sessionMapObj.put("excluirSistema", sistema);

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	public void ExcluirSistema(Sistema sistema) {
		try {

			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			SistemaDAO dao = new SistemaDAO(conexao);
			dao.Excluir(sistema);

			this.sistemas = dao.ListarTodos();

			fabrica.fecharConexao();

			JSFUtil.adicionarMensagemSucesso("Sistema exclu�do com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}

	@PostConstruct
	public void init() {
		try {

			this.sistema = new Sistema();

			FabricaConexao fabrica = new FabricaConexao();
			Connection conexao = fabrica.fazerConexao();

			SistemaDAO dao = new SistemaDAO(conexao);
			this.sistemas = dao.ListarTodos();

			fabrica.fecharConexao();

		} catch (Exception e) {
			e.printStackTrace();
			JSFUtil.adicionarMensagemErro(e.getMessage());
		}
	}
}
