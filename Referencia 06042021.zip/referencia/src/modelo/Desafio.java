package modelo;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import util.ModeloBase;

public class Desafio extends ModeloBase {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private String titulo;
	private String desc;
	private Status status;
	private Especialidade especialidade;
	private Reacao reacao;
	private Usuario usuario;
	private Long idRespostaAceita;
	private Timestamp dt_cadastro;
	private Timestamp dt_ultima_resposta;
	private List<Resposta> respostas;
	
	public Desafio() {
		this.id = new Long(0);
		this.respostas = new ArrayList<Resposta>();
		this.especialidade = new Especialidade();
		this.usuario = new Usuario();
		this.reacao = new Reacao();
		this.status = new Status();
	}
	
	public Desafio(Long id, String titulo, String desc, Status status, Especialidade especialidade, Usuario usuario, Long idRespostaAceita, Timestamp dt_cadastro, Timestamp dt_ultima_resposta, List<Resposta> respostas) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.desc = desc;
		this.status = status;	
		this.especialidade = especialidade;
		this.usuario = usuario;
		this.idRespostaAceita = idRespostaAceita;
		this.dt_cadastro = dt_cadastro;
		this.dt_ultima_resposta = dt_ultima_resposta;
		this.respostas = respostas;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
		
	public Timestamp getDataCadastro() {
		return dt_cadastro;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Especialidade getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}

	public Reacao getReacao() {
		return reacao;
	}

	public void setReacao(Reacao reacao) {
		this.reacao = reacao;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Long getIdRespostaAceita() {
		return idRespostaAceita;
	}

	public void setIdRespostaAceita(Long idRespostaAceita) {
		this.idRespostaAceita = idRespostaAceita;
	}

	public Timestamp getDt_cadastro() {
		return dt_cadastro;
	}
	
	public void setDt_cadastro(Timestamp dt_cadastro) {
		this.dt_cadastro = dt_cadastro;
	}

	public void setDataCadastro(Timestamp dt_cadastro) {
		this.dt_cadastro = dt_cadastro;
	}
	
	public Timestamp getDt_ultima_resposta() {
		return dt_ultima_resposta;
	}
	
	public void setDt_ultima_resposta(Timestamp dt_ultima_resposta) {
		this.dt_ultima_resposta = dt_ultima_resposta;
	}
	
	public List<Resposta> getRespostas() {
		return respostas;
	}

	public void setRespostas(List<Resposta> respostas) {
		this.respostas = respostas;
	}

	public String getStr_Dt_cadastro() {
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String str = fmt.format(dt_cadastro);
		return str;
	}
	
	public String getStr_Dt_ultima_resposta() {
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String str = "";
		
		if (dt_ultima_resposta != null) {
			str = fmt.format(dt_ultima_resposta);
		}else {
			str = "";
		}
		
		return str;
	}
	
	@Override
	public String toString() {
		return "Desafio [id=" + id + ", titulo=" + titulo + ", desc=" + desc + ", status=" + status + ", especialidade="
				+ especialidade + ", reacao=" + reacao + ", usuario=" + usuario + ", id_resposta_aceita="
				+ idRespostaAceita + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Desafio other = (Desafio) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        
        return true;
	}
}
