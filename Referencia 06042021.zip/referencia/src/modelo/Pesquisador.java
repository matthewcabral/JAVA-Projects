package modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Pesquisador extends Usuario {

	private static final long serialVersionUID = 1L;
	private String instituto;
	private List<Especialidade> especialidades;

	public Pesquisador() {
		super();
		this.especialidades = new ArrayList<Especialidade>();
	}
	
	public Pesquisador(Long id, String nome, String senha, String senhaConfirmar, String tel, String email, Date dtCadastro, String instituto, String tipoUsuario, String status, Date dtStatus, List<Especialidade> especialidades) {
		super(id, nome, senha, senhaConfirmar, tel, email, dtCadastro, tipoUsuario, status, dtStatus);
		this.instituto = instituto;
		this.especialidades = especialidades;
	}
	
	public Pesquisador(Usuario _usuario) {
		super(_usuario.id, _usuario.nome, _usuario.senha, _usuario.senhaConfirmar, _usuario.tel, _usuario.email, _usuario.dataCadastro, _usuario.tipoUsuario, _usuario.status, _usuario.dataStatus);
	}

	public String getInstituto() {
		return instituto;
	}

	public void setInstituto(String instituto) {
		if (!instituto.equals("")) {
			this.instituto = instituto;
		}	
	}

	public void setUsuario(Usuario _usuario) {
		this.id = _usuario.id;
		this.nome = _usuario.nome;
		this.senha = _usuario.senha;
		this.tel = _usuario.tel;
		this.email = _usuario.email;
		this.dataCadastro = _usuario.dataCadastro;
		this.tipoUsuario = _usuario.tipoUsuario;
	}
	
	public List<Especialidade> getEspecialidades() {
		return especialidades;
	}

	public void setEspecialidades(List<Especialidade> especialidades) {
		this.especialidades = especialidades;
	}

	@Override
	public String toString() {
		return "Pesquisador [instituto=" + instituto + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Usuario other = (Usuario) obj;
        
        return super.equals(other);
	}
}
