package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Especialidade;
import modelo.Pesquisador;
import modelo.TipoUsuario;
import modelo.Usuario;

public class PesquisadorDAO implements InterfacePesquisadorDAO {

	Connection conexao;

	public PesquisadorDAO(Connection _conexao) {
		this.conexao = _conexao;
	}

	@Override
	public void InserirNovo(Pesquisador _pesquisador) throws SQLException {

		String comando = "insert into usuario (id, nome, login, senha, tel, email, dtCadastro, tipo_usuario) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement ps = this.conexao.prepareStatement(comando);
		ps.setLong(1, _pesquisador.getId());
		ps.setString(2, _pesquisador.getNome());
		ps.setString(3, _pesquisador.getLogin());
		ps.setString(4, _pesquisador.getSenha());
		ps.setString(5, _pesquisador.getTel());
		ps.setString(6, _pesquisador.getEmail());
		ps.setDate(7, new Date(_pesquisador.getDataCadastro().getTime()));
		ps.setLong(8, _pesquisador.getTipoUsuario().getId());

		ps.execute();
	}

	@Override
	public void InserirExiste(Pesquisador _pesquisador) throws SQLException {

		String comando = "insert into usuario_especialidade (usuario, especialidade) "
				+ "values (?, ?)";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisador.getId());
		//ps.setLong(2, _pesquisador.getIdEspecialidade());

		ps.execute();

	}

	@Override
	public void InserirEspecialidade(Long _pesquisadorId, Long _especialidadeId) throws SQLException {
		
  		String comando = "insert into usuario_especialidade (usuario, especialidade) "
				+ "values (?, ?)";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisadorId);
		ps.setLong(2, _especialidadeId);

		ps.execute();    
	   
		
	}	
	
	@Override
	public void InserirEspecialidades(Pesquisador _pesquisador) throws SQLException {
		
		for (int counter = 0; counter < _pesquisador.getEspecialidades().size(); counter++) { 		      
	          
	  		String comando = "insert into usuario_especialidade (usuario, especialidade) "
					+ "values (?, ?)";

			PreparedStatement ps = this.conexao.prepareStatement(comando);

			ps.setLong(1, _pesquisador.getId());
			ps.setLong(2, _pesquisador.getEspecialidades().get(counter).getId());

			ps.execute();    
	   }
		
	}
	
	@Override
	public void RemoverEspecialidade(Long _pesquisadorId, Long _especialidadeId) throws SQLException {
		
  		String comando = "delete from usuario_especialidade "
				+ "where usuario = ? and especialidade = ?";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisadorId);
		ps.setLong(2, _especialidadeId);

		ps.execute();    
	   
		
	}	
	
	@Override
	public void EditarEspecialidades(Long _idPesquisador, String _idsEspecialidades) throws SQLException {
		       
  		String comando = "delete from usuario_especialidade "
  				+ "where usuario = ? and "
				+ "especialidade not in (" + _idsEspecialidades + ")";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _idPesquisador);

		ps.execute();    
		
		
  		comando = "insert into usuario_especialidade (usuario, especialidade) "
  				+ "select ?, id "
				+ "from especialidade "
				+ "where id in (" + _idsEspecialidades + ") and "
				+ "id not in (select especialidade from usuario_especialidade where usuario = ?)";

		ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _idPesquisador);
		ps.setLong(2, _idPesquisador);

		ps.execute();    
	   
		
	}
	
	@Override
	public List<Pesquisador> listarTodos() throws SQLException {

		ResultSet rs = null;
		List<Pesquisador> listaPesquisadors = new ArrayList<Pesquisador>();

		String comando = "SELECT "
				+ "id, "
				+ "nome, "
				+ "login, "
				+ "senha, "
				+ "tel, "
				+ "email, "
				+ "dtCadastro, "
				+ "tipo_usuario, "
				+ "status, "
				+ "dtStatus, "
				+ "instituto "
				+ "FROM usuario";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		rs = ps.executeQuery();

		while (rs.next()) {
			Long id = rs.getLong(1);
			String nome = rs.getString(2);
			String login = rs.getString(3);
			String senha = rs.getString(4);
			String tel = rs.getString(5);
			String email = rs.getString(6);
			Date dtCadastro = rs.getDate(7);
			Long idTipoUsuario = rs.getLong(8);
			Integer status = rs.getInt(9);
			Date dtStatus = rs.getDate(10);
			String instituto = rs.getString(11);

			//EspecialidadeDAO daoEsp = new EspecialidadeDAO(this.conexao);
			//Especialidade especialidade = daoEsp.PegarPeloID(idEspecialidade);
			
			TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
            TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
            
            EspecialidadeDAO daoEspecialidade = new EspecialidadeDAO(conexao);
            List<Especialidade> especialidades = daoEspecialidade.TodasEspecialidadesDoUsuario(id);

			Pesquisador o = new Pesquisador(id, nome, login, senha, senha, tel, email, dtCadastro, instituto, tipoUsuario, status, dtStatus, especialidades);
			
			listaPesquisadors.add(o);
		}

		return listaPesquisadors;
	}

	@Override
	public void Editar(Pesquisador _pesquisador) throws SQLException {

		String comandoU = "update usuario set nome = ?, login = ?, senha = ?, tel = ?, email = ?, tipo_usuario = ?, instituto = ? where id = ?";

		PreparedStatement ps = this.conexao.prepareStatement(comandoU);

		ps.setString(1, _pesquisador.getNome());
		ps.setString(2, _pesquisador.getEmail());
		ps.setString(3, _pesquisador.getSenha());
		ps.setString(4, _pesquisador.getTel());
		ps.setString(5, _pesquisador.getEmail());
		ps.setLong(6, _pesquisador.getTipoUsuario().getId());
		ps.setString(7, _pesquisador.getInstituto());

		ps.setLong(8, _pesquisador.getId());
		
		ps.execute();	
		
	}

	@Override
	public void EditarExiste(Pesquisador _pesquisador) throws SQLException {
		
		String comando = "insert into usuario_especialidade (usuario, especialidade) "
				+ "values (?, ?)";
		
		PreparedStatement ps = this.conexao.prepareStatement(comando);
		
		ps.setLong(1, _pesquisador.getId());
		//ps.setLong(2, _pesquisador.getEspecialidade().getId());
		
		ps.execute();
	}	
	
	@Override
	public Long PegarProximoID()throws SQLException {

		Long id = new Long(0);

		String comando = "SELECT Auto_increment FROM information_schema.tables WHERE table_name='usuario'";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
			id = rs.getLong(1);
		}

		return id;
	}

	@Override
	public void Aprovar(Pesquisador _pesquisador) throws SQLException {

		String comando = "update usuario set status = 1 where id = ?";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisador.getId());

		ps.execute();

	}	
	
	@Override
	public void Excluir(Pesquisador _pesquisador) throws SQLException {

		String comando = "delete from usuario_especialidade where usuario = ?";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisador.getId());

		ps.execute();
		
		comando = "delete from usuario where id = ?";
		
		ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _pesquisador.getId());

		ps.execute();
		
	}

	@Override
	public Pesquisador PegarPeloID(Long _id) throws SQLException {

		ResultSet rs = null;

		String comando = "SELECT "
				+ "id, "
				+ "nome, "
				+ "login, "
				+ "senha, "
				+ "tel, "
				+ "email, "
				+ "dtCadastro, "
				+ "tipo_usuario, "
				+ "instituto, "
				+ "status, "
				+ "dtStatus "
				+ "FROM usuario "
				+ "WHERE id = ?";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _id);
		
		rs = ps.executeQuery();

		if (rs.next()) {
			Long id = rs.getLong(1);
			String nome = rs.getString(2);
			String login = rs.getString(3);
			String senha = rs.getString(4);
			String tel = rs.getString(5);
			String email = rs.getString(6);
			Date dtCadastro = rs.getDate(7);
			Long idTipoUsuario = rs.getLong(8);
			String instituto = rs.getString(9);
			Integer status = rs.getInt(10);
			Date dtStatus = rs.getDate(11);

            TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
            TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
            
			EspecialidadeDAO daoEsp = new EspecialidadeDAO(this.conexao);
			List<Especialidade> especialidades = daoEsp.TodasEspecialidadesDoUsuario(id);

			return new Pesquisador(id, nome, login, senha, senha, tel, email, dtCadastro, instituto, tipoUsuario, status, dtStatus, especialidades);
		}
		else {
			return null;
		}
	}
	
	@Override
	public List<Usuario> listarUsuariosParaPesquisador() {
		
		ResultSet rs = null;
		List<Usuario> listaUsuarios = new ArrayList<Usuario>();
		
		try {
			
			String comando = "SELECT u.id, u.nome, u.login, u.senha, u.tel, u.email, u.dtCadastro, u.tipo_usuario, u.status, u.dtStatus "
					+ "FROM usuario u WHERE u.id NOT IN (SELECT p.id FROM pesquisador p);";
			
			PreparedStatement ps = this.conexao.prepareStatement(comando);
			
			rs = ps.executeQuery();
			
			while (rs.next()) {
                Long id = rs.getLong(1);
                String nome = rs.getString(2);
                String login = rs.getString(3);
                String senha = rs.getString(4);
                String tel = rs.getString(5);
                String email = rs.getString(6);
                Date dtCadastro = rs.getDate(7);
                Long idTipoUsuario = rs.getLong(8);
                Integer status = rs.getInt(9);
                Date dtStatus = rs.getDate(10);

                TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
                TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
                
                listaUsuarios.add(new Usuario(id, nome, login, senha, senha, tel, email, dtCadastro, tipoUsuario, status, dtStatus));
            }
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		return listaUsuarios;
	}

	@Override
	public List<Pesquisador> listarTodosPorEspecialidade(Long _idEspecialidade) throws SQLException {

		ResultSet rs = null;
		List<Pesquisador> listaPesquisadors = new ArrayList<Pesquisador>();

		String comando = "SELECT "
				+ "u.id, "
				+ "u.nome, "
				+ "u.login, "
				+ "u.senha, "
				+ "u.tel, "
				+ "u.email, "
				+ "u.dtCadastro, "
				+ "u.tipo_usuario, "
				+ "u.status, "
				+ "u.dtStatus, "
				+ "u.instituto "
				+ "FROM usuario u, usuario_especialidade ue "
				+ "WHERE u.id = ue.usuario "
				+ "AND ue.especialidade = ?;";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _idEspecialidade);
		
		rs = ps.executeQuery();

		while (rs.next()) {
			Long id = rs.getLong(1);
			String nome = rs.getString(2);
			String login = rs.getString(3);
			String senha = rs.getString(4);
			String tel = rs.getString(5);
			String email = rs.getString(6);
			Date dtCadastro = rs.getDate(7);
			Long idTipoUsuario = rs.getLong(8);
			Integer status = rs.getInt(9);
			Date dtStatus = rs.getDate(10);
			String instituto = rs.getString(11);
			
			TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
            TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
            
			EspecialidadeDAO daoEsp = new EspecialidadeDAO(this.conexao);
			List<Especialidade> especialidades = daoEsp.TodasEspecialidadesDoUsuario(id);

			Pesquisador o = new Pesquisador(id, nome, login, senha, senha, tel, email, dtCadastro, instituto, tipoUsuario, status, dtStatus, especialidades);
			
			listaPesquisadors.add(o);
		}

		return listaPesquisadors;
	}

	@Override
	public List<Pesquisador> listarTodosSemEspecialidade(Long _idEspecialidade) throws SQLException {

		ResultSet rs = null;
		List<Pesquisador> listaPesquisadors = new ArrayList<Pesquisador>();

		String comando = "SELECT "
				+ "u.id, "
				+ "u.nome, "
				+ "u.login, "
				+ "u.senha, "
				+ "u.tel, "
				+ "u.email, "
				+ "u.dtCadastro, "
				+ "u.tipo_usuario, "
				+ "u.status, "
				+ "u.dtStatus, "
				+ "u.instituto "
				+ "FROM usuario u "
				+ "WHERE u.id not in (select ue.usuario from usuario_especialidade ue where ue.especialidade = ?);";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		ps.setLong(1, _idEspecialidade);
		
		rs = ps.executeQuery();

		while (rs.next()) {
			Long id = rs.getLong(1);
			String nome = rs.getString(2);
			String login = rs.getString(3);
			String senha = rs.getString(4);
			String tel = rs.getString(5);
			String email = rs.getString(6);
			Date dtCadastro = rs.getDate(7);
			Long idTipoUsuario = rs.getLong(8);
			Integer status = rs.getInt(9);
			Date dtStatus = rs.getDate(10);
			String instituto = rs.getString(11);
			
			TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
            TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
            
			EspecialidadeDAO daoEsp = new EspecialidadeDAO(this.conexao);
			List<Especialidade> especialidades = daoEsp.TodasEspecialidadesDoUsuario(id);

			Pesquisador o = new Pesquisador(id, nome, login, senha, senha, tel, email, dtCadastro, instituto, tipoUsuario, status, dtStatus, especialidades);
			
			listaPesquisadors.add(o);
		}

		return listaPesquisadors;
	}
	
	@Override
	public List<Pesquisador> listarPesquisadoresPendentes() throws SQLException {

		ResultSet rs = null;
		List<Pesquisador> listaPesquisadors = new ArrayList<Pesquisador>();

		String comando = "SELECT "
				+ "id, "
				+ "nome, "
				+ "login, "
				+ "senha, "
				+ "tel, "
				+ "email, "
				+ "dtCadastro, "
				+ "tipo_usuario, "
				+ "status, "
				+ "dtStatus, "
				+ "instituto "
				+ "FROM usuario "
				+ "WHERE usuario.status=0;";

		PreparedStatement ps = this.conexao.prepareStatement(comando);

		rs = ps.executeQuery();

		while (rs.next()) {
			Long id = rs.getLong(1);
			String nome = rs.getString(2);
			String login = rs.getString(3);
			String senha = rs.getString(4);
			String tel = rs.getString(5);
			String email = rs.getString(6);
			Date dtCadastro = rs.getDate(7);
			Long idTipoUsuario = rs.getLong(8);
			Integer status = rs.getInt(9);
			Date dtStatus = rs.getDate(10);
			String instituto = rs.getString(11);

			TipoUsuarioDAO daoTU = new TipoUsuarioDAO(conexao);
            TipoUsuario tipoUsuario = daoTU.PegarPeloID(idTipoUsuario);
            
			EspecialidadeDAO daoEsp = new EspecialidadeDAO(this.conexao);
			List<Especialidade> especialidades = daoEsp.TodasEspecialidadesDoUsuario(id);

			Pesquisador o = new Pesquisador(id, nome, login, senha, senha, tel, email, dtCadastro, instituto, tipoUsuario, status, dtStatus, especialidades);
			
			listaPesquisadors.add(o);
		}

		return listaPesquisadors;
	}
	
}
