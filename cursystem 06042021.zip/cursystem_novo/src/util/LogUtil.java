package util;

public class LogUtil {

}
