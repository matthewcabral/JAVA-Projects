package util;

public interface EntidadeBase {
	
	public Long getId();
}
